# A10 Core to H0 Kernel Deconstruction — Phase 1.5 Seed Dossier Builder

This package converts the Phase 1 textual bridge output into a human-readable handoff dossier for a future ΛCDM-comparator H0 residual-kernel project.

Phase 1.5 does not perform cosmological likelihood testing. It consolidates Phase 1 evidence into a dossier that can later be merged with separate ΛCDM destruction-test outputs.
