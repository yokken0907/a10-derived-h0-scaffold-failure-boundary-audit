#!/usr/bin/env python3
import argparse, csv, hashlib, json, zipfile
from pathlib import Path
from datetime import datetime, timezone

KEEP_PREFIXES = ("KEEP",)
ARCHIVE_PREFIXES = ("ARCHIVE",)

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})

def load_phase1(zip_path: Path):
    if not zip_path.exists():
        raise FileNotFoundError(f"Phase 1 output zip not found: {zip_path}")
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist()
        root=None
        for name in names:
            if name.endswith("outputs/a10_element_stripping_audit.json"):
                root=name.split("/outputs/")[0]
                break
        if not root:
            raise RuntimeError("Could not locate outputs/a10_element_stripping_audit.json in Phase 1 ZIP")
        def read_json(rel):
            return json.loads(z.read(f"{root}/outputs/{rel}").decode("utf-8"))
        def read_text(rel):
            return z.read(f"{root}/outputs/{rel}").decode("utf-8", errors="replace")
        return {
            "audit": read_json("a10_element_stripping_audit.json"),
            "evidence": read_json("source_evidence_contexts.json"),
            "ablation": read_json("ablation_test_matrix.json"),
            "bridge": read_json("destruction_bridge_template.json"),
            "neutral_kernel_definition": read_text("neutral_kernel_definition.md"),
            "no_go_claim_boundary": read_text("no_go_claim_boundary.md"),
            "phase1_summary": read_json("phase1_textual_deconstruction_summary.json"),
            "root": root,
        }

def classify_status(status: str) -> str:
    if status.startswith(KEEP_PREFIXES):
        return "CARRY_FORWARD_CANDIDATE"
    if status.startswith(ARCHIVE_PREFIXES):
        return "ARCHIVE_ONLY"
    return "DEFER_OR_ABLATE"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--phase1-output-zip", required=True)
    ap.add_argument("--out", default="outputs")
    args=ap.parse_args()
    out=Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out/"data").mkdir(exist_ok=True)

    phase1_zip=Path(args.phase1_output_zip)
    data=load_phase1(phase1_zip)
    audit=data["audit"]
    evidence=data["evidence"]
    ablation=data["ablation"]
    bridge=data["bridge"]

    evidence_by_component={}
    for ev in evidence:
        evidence_by_component.setdefault(ev.get("component_id",""),[]).append(ev)

    ledger=[]
    for row in audit:
        cid=row.get("component_id","")
        phase1_status=row.get("phase1_status","")
        handoff=classify_status(phase1_status)
        ledger.append({
            "component_id": cid,
            "neutralized_component": row.get("neutralized_component",""),
            "phase1_status": phase1_status,
            "handoff_status": handoff,
            "evidence_context_count": len(evidence_by_component.get(cid, [])),
            "a10_stripping_action": row.get("a10_stripping_action",""),
            "merge_requirement": "Merge with separate ΛCDM destruction-test outputs before any theoretical promotion.",
            "next_project_permission": "candidate_input_only" if handoff=="CARRY_FORWARD_CANDIDATE" else "not_primary_input_without_new_evidence",
        })

    kernel_matrix=[]
    for row in ledger:
        status=row["handoff_status"]
        if status=="CARRY_FORWARD_CANDIDATE":
            required_tests="ΛCDM comparator; ΔNeff benchmark; EDE benchmark; CMB TT/EE/TE residual; BAO/SN residual; prior sensitivity; no-gate/generic-gate ablation"
            candidate_role="primary_or_mandatory_kernel_support"
        elif status=="DEFER_OR_ABLATE":
            required_tests="ablation-only; do not promote unless independent comparator improvement appears"
            candidate_role="secondary_ablation_or_symbolic_coordinate"
        else:
            required_tests="archive only; no promotion route in new H0 theory"
            candidate_role="archive_only"
        kernel_matrix.append({
            "component_id": row["component_id"],
            "component": row["neutralized_component"],
            "handoff_status": status,
            "candidate_role": candidate_role,
            "required_tests_before_use": required_tests,
            "do_not_claim": "physical validation, H0 solution, ΛCDM replacement, 137 proof",
        })

    write_json(out/"data/component_status_ledger.json", ledger)
    write_csv(out/"data/component_status_ledger.csv", ledger, list(ledger[0].keys()))
    write_json(out/"data/kernel_candidate_matrix.json", kernel_matrix)
    write_csv(out/"data/kernel_candidate_matrix.csv", kernel_matrix, list(kernel_matrix[0].keys()))
    write_json(out/"data/destruction_merge_template.json", bridge)
    write_csv(out/"data/destruction_merge_template.csv", bridge, list(bridge[0].keys()))
    write_json(out/"data/ablation_test_matrix.json", ablation)
    write_csv(out/"data/ablation_test_matrix.csv", ablation, list(ablation[0].keys()))
    write_json(out/"data/source_evidence_index.json", evidence)
    write_csv(out/"data/source_evidence_index.csv", evidence, list(evidence[0].keys()))

    keep=[r for r in ledger if r["handoff_status"]=="CARRY_FORWARD_CANDIDATE"]
    defer=[r for r in ledger if r["handoff_status"]=="DEFER_OR_ABLATE"]
    archive=[r for r in ledger if r["handoff_status"]=="ARCHIVE_ONLY"]
    summary={
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "phase1_output_zip": str(phase1_zip),
        "phase1_source_sha256": sha256_bytes(phase1_zip.read_bytes()),
        "component_count": len(ledger),
        "carry_forward_candidate_count": len(keep),
        "defer_or_ablate_count": len(defer),
        "archive_only_count": len(archive),
        "evidence_context_count": len(evidence),
        "ablation_test_count": len(ablation),
        "destruction_merge_component_count": len(bridge),
    }
    write_json(out/"PHASE1_5_SEED_DOSSIER_SUMMARY.json", summary)

    def table(rows):
        lines=["| component_id | handoff_status | component |", "|---|---|---|"]
        for r in rows:
            lines.append(f"| {r['component_id']} | {r['handoff_status']} | {r['neutralized_component']} |")
        return "\n".join(lines)

    readme = f"""# A10 Core to New H0 Project Seed Dossier

This dossier consolidates Phase 1 textual deconstruction into a handoff-ready structure for a future ΛCDM-comparator H0 residual-kernel project.

## Status

```text
Phase 1.5 status: DOSSIER_READY_FOR_DESTRUCTION_LOG_MERGE
Numerical cosmology status: NOT_TESTED_HERE
Claim status: PRE-VALIDATION_ONLY
```

## Counts

```json
{json.dumps(summary, ensure_ascii=False, indent=2)}
```

## Component ledger

{table(ledger)}

## Next required step

Merge this dossier with the separate ΛCDM destruction-test output. No component should be promoted before that merge.
"""
    (out/"README.md").write_text(readme, encoding="utf-8")
    (out/"CLAIM_BOUNDARY.md").write_text(data["no_go_claim_boundary"], encoding="utf-8")
    (out/"NEUTRAL_KERNEL_SEED.md").write_text(data["neutral_kernel_definition"] + "\n\n## Phase 1.5 handoff interpretation\n\nThis is a candidate seed only. It must be tested against ΛCDM, ΔNeff-like, and EDE-like comparators before any promotion.\n", encoding="utf-8")
    (out/"A10_STRIPPING_SUMMARY.md").write_text("# A10 Element Stripping Summary\n\n" + table(ledger) + "\n", encoding="utf-8")
    (out/"DESTRUCTION_MERGE_PREP.md").write_text("# Destruction Merge Preparation\n\nUse `data/destruction_merge_template.csv` as the receiving table for the separate ΛCDM destruction-test outputs.\n\nRequired merge fields:\n\n```text\nlcdm_comparator_result\nbenchmark_delta_neff_result\nbenchmark_ede_result\ncmb_tt_cost\ncmb_ee_te_cost\nbao_sn_cost\nprior_sensitivity\nrecommendation_after_merge\n```\n\nPromotion rule:\n\n```text\nA component may only move from candidate to usable seed if it survives comparator, benchmark, perturbative, residual-cost, and prior-sensitivity checks.\n```\n", encoding="utf-8")
    (out/"NO_GO_LEDGER.md").write_text("# No-Go Ledger\n\nDo not carry forward:\n\n```text\n- A10 as evidence for cosmology.\n- χ≈137 as a proven cosmological constant.\n- Root geometry / E8 / ADE as physical evidence.\n- High H0 as a standalone success criterion.\n- Background-only agreement as validation.\n- Any claim of Hubble tension solution.\n```\n", encoding="utf-8")
    (out/"NEXT_PROJECT_HANDOFF.md").write_text("# Next Project Handoff\n\nRecommended new-project frame:\n\n```text\nLocalized Early-Time Residual-Response Audit\n```\n\nCore task:\n\n```text\nTest whether a neutral compact pre-recombination transfer parameterization can alter sound-horizon/H0 inference while controlling CMB TT/EE/TE, BAO, SN, prior-sensitivity, and benchmark-comparator residual costs.\n```\n\nDo not start the new H0 theory as an A10 theory. Start it as a ΛCDM-comparator diagnostic project.\n", encoding="utf-8")

    manifest=[]
    for path in sorted([p for p in out.rglob("*") if p.is_file()]):
        rel=str(path.relative_to(out))
        b=path.read_bytes()
        manifest.append({"path": rel, "size_bytes": len(b), "sha256": sha256_bytes(b)})
    write_json(out/"OUTPUT_MANIFEST.json", manifest)
    write_csv(out/"OUTPUT_MANIFEST.csv", manifest, ["path","size_bytes","sha256"])
    (out/"MANIFEST_VERIFY_PASS.txt").write_text("PASS: Phase 1.5 seed dossier outputs generated.\n", encoding="utf-8")

if __name__ == "__main__":
    main()
