# WSL One-Shot Run

```bash
mkdir -p ~/a10_projects/a10-cosmology-v050-validation-workbench
cd ~/a10_projects/a10-cosmology-v050-validation-workbench

rm -rf a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier
unzip /mnt/c/Users/KEI/Downloads/a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier.zip

cd a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier

python3 scripts/run_phase1_5_seed_dossier.py \
  --phase1-output-zip /mnt/c/Users/KEI/Downloads/a10_core_to_h0_kernel_deconstruction_phase1_textual_bridge_output\(1\).zip \
  --out outputs

cd ..

zip -r a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier_output.zip \
  a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier \
  -x 'a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier/.git/*' \
     'a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier/__pycache__/*' \
     'a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier/**/*.pyc'

cp a10_core_to_h0_kernel_deconstruction_phase1_5_seed_dossier_output.zip /mnt/c/Users/KEI/Downloads/
```
